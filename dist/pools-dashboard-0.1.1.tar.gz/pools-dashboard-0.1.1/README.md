# pools-analytics

### Deployed at
https://galenhew-pool-analytics-srcpools-dashboarddashboard-3ao0eg.streamlitapp.com/

### Scope
1. dashboard for bets 
2. poisson odds model
3. other models
4. add DB 

### Code
- FE prototyping on streamlit

- to install dependencies via poetry
  - ```poetry install```

- to run streamlit locally
  - ```streamlit run dashboard.py ```

